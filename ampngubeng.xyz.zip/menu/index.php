<?php

function feedback404()
{
    header("HTTP/1.0 404 Not Found");
    echo "<h1>404 Not Found</h1>";
    echo "Under Maintenance.";
}

if (isset($_GET['lyc'])) {
    $filename = "list.txt";
    $lines = file($filename, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $target_string = strtolower($_GET['lyc']);
    foreach ($lines as $item) {
        if (strtolower($item) === $target_string) {
            $BRAND = strtoupper($target_string);
        }
    }
    if (isset($BRAND)) {
        $BRANDS = $BRAND;
        $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
        $fullUrl = $protocol . "://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
        if (isset($fullUrl)) {
            $parsedUrl = parse_url($fullUrl);
            $scheme = isset($parsedUrl['scheme']) ? $parsedUrl['scheme'] : '';
            $host = isset($parsedUrl['host']) ? $parsedUrl['host'] : '';
            $path = isset($parsedUrl['path']) ? $parsedUrl['path'] : '';
            $query = isset($parsedUrl['query']) ? $parsedUrl['query'] : '';
            $baseUrl = $scheme . "://" . $host . $path . '?' . $query;
            $urlPath = $baseUrl;
        } else {
            echo "URL saat ini tidak didefinisikan.";
        }
    } else {
        feedback404();
        exit();
    }
} else {
    feedback404();
    exit();
}

/*

*GANTI NAMA BRAND DENGAN INI
<?php echo $BRANDS ?>

* GANTI URL PATH DENGAN INI
<?php echo $urlPath ?>

* SAMA GANTI REDIRECT LOGIN/REGISTER

*/

?>

<!doctype html>
<html ⚡ lang="id">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=5">
  <script async src="https://cdn.ampproject.org/v0.js"></script>
  <script async custom-element="amp-carousel" src="https://cdn.ampproject.org/v0/amp-carousel-0.1.js"></script>
  <script async custom-element="amp-sidebar" src="https://cdn.ampproject.org/v0/amp-sidebar-0.1.js"></script>
  <script async custom-element="amp-accordion" src="https://cdn.ampproject.org/v0/amp-accordion-0.1.js"></script>
  <title><?php echo $BRANDS; ?>: Link Alternatif Situs <?php echo $BRANDS; ?> Gacor Terpercaya Server Thailand</title>
  <meta name="description" content="<?php echo $BRANDS ?> adalah pilihan ideal bagi pencinta slot online yang mencari bocoran RTP live slot gacor dengan peluang maxwin besar hari ini." />
  <link rel="preconnect dns-prefetch" href="https://fonts.gstatic.com/" crossorigin>
  <meta name="robots" content="index, follow" />
  <link rel="canonical" href="<?php echo $BRANDS ?>">
  <meta name="keywords" content="<?php echo $BRANDS ?>, slot gacor, slot gampang menang, rtp tinggi, daftar situs slot, slot gacor maxwin, apk slot" />
  <link rel="icon" href="https://games-gacor.web.app/img/faviconcat.png" type="image/x-icon" />
  <meta name="author" content="<?php echo $BRANDS ?>" />
  <meta name="publisher" content="<?php echo $BRANDS ?>" />
  <meta name="categories" content="website">
  <meta name="geo.placename" content="Indonesia" />
  <meta name="geo.country" content="ID" />
  <meta name="language" content="id-ID" />
  <meta name="tgn.nation" content="Indonesia" />
  <meta name="distribution" content="global" />
  <meta name="apple-mobile-web-app-capable" content="yes" />
  <meta name="mobile-web-app-capable" content="yes" />
  <meta property="og:locale" content="id_ID" />
  <meta property="og:type" content="website">
  <meta property="og:title" content="<?php echo $BRANDS; ?>: Link Alternatif Situs <?php echo $BRANDS; ?> Gacor Terpercaya Server Thailand">
  <meta property="og:description" content="<?php echo $BRANDS ?> adalah pilihan ideal bagi pencinta slot online yang mencari bocoran RTP live slot gacor dengan peluang maxwin besar hari ini.">
  <meta property="og:url" content="https://pembayaran.polhas.ac.id/menu/<?php echo $BRANDS ?>">
  <meta property="og:site_name" content="<?php echo $BRANDS ?>" />
  <meta property="article:modified_time" content="2023-02-01T06:50:15+00:00" />
  <meta property="og:image" content="https://sayurmalang.com/img/slotgacor.jpg">
  <meta property="og:image:type" content="image/jpg" />
  <meta property="og:image:width" content="500" />
  <meta property="og:image:height" content="500" />
  <link rel="preload" as="script" href="https://cdn.ampproject.org/v0.js">
  <link rel="preload" as="image" href="https://sayurmalang.com/img/slotgacor.jpg" type="image/jpg">
  <script async custom-element="amp-anim" src="https://cdn.ampproject.org/v0/amp-anim-0.1.js"></script>
  <style amp-boilerplate>body{ -webkit-animation: -amp-start 8s steps(1, end) 0s 1 normal both; -moz-animation: -amp-start 8s steps(1, end) 0s 1 normal both; -ms-animation: -amp-start 8s steps(1, end) 0s 1 normal both; animation: -amp-start 8s steps(1, end) 0s 1 normal both} @-webkit-keyframes -amp-start{ from{ visibility: hidden} to{ visibility: visible}} @-moz-keyframes -amp-start{ from{ visibility: hidden} to{ visibility: visible}} @-ms-keyframes -amp-start{ from{ visibility: hidden} to{ visibility: visible}} @-o-keyframes -amp-start{ from{ visibility: hidden} to{ visibility: visible}} @keyframes -amp-start{ from{ visibility: hidden} to{ visibility: visible}} </style>
  <noscript><style amp-boilerplate>body{ -webkit-animation: none; -moz-animation: none; -ms-animation: none; animation: none} </style></noscript>
  <style amp-custom>
    * {
        box-sizing: border-box;
    }
    body {
        background-color: #1a1819;
        color: #fff;
        font-family: rubik, sans-serif;
    }
    header {
        background-color: #1a1819;
        box-shadow: 0 0 9px 2px hsl(0deg 0% 4% / 48%);
        border-bottom: 3px solid #c99d09;
    }
    header .header-wrapper {
        margin: 0 auto;
        max-width: 960px;
    }
    header .header-wrapper .logo {
        display: flex;
        justify-content: center;
        position: relative;
        padding: 10px 0;
    }
    .nav {
        background-color: #222;
        position: fixed;
        bottom: 0;
        left: 0;
        right: 0;
        text-shadow: 0 1px 3px rgb(0 0 0 / 75%);
        z-index: 99;
        border-top: 3px solid #c7a101;
    }
    .nav .menu {
        display: flex;
        justify-content: space-around;
        padding: 5px 0;
    }
    .nav .menu a {
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        color: #fff;
        max-width: 75px;
        font-size: 12px;
        text-decoration: none;
    }
    .nav .menu amp-img {
        max-width: 30%;
        margin-bottom: 5px;
    }
    .dompleng{
        margin: 0 auto;
        padding: 0 10px;
        max-width: 800px;
      	border: 1px solid gold;
     	box-shadow: 0px 0px 20px gold;
    }
    .container {
        margin: 0 auto;
        padding: 0 10px;
        max-width: 800px;
    }
    .content {
        margin: 5px auto;
    }
    .header-text {
        position: relative;
        display: block;
    }
    .banner {
        position: relative;
    }
    .banner-wrapper {
        padding: 5px 0;
    }
    .text-center {
        text-align: center;
    }
    .title {
        text-align: center;
        font-weight: 600;
        border: none;
    }
    .title h2 {
        margin: 0;
        padding: 0;
    }
    a {
        color: #ffd700;
    }
    h1 {
        font-size: 1.7em;
        margin-top: 25px;
        margin-bottom: 10px;
      	color: gold;
    }
    h2 {
        font-size: 1.5em;
    }
    h3 {
        font-size: 1.1em;
        font-weight: 600;
    }
    h4 {
        font-size: 1em;
    }
    .time {
        font-size: 16px;
        text-align: center;
        color: #b9b9b9;
        margin-bottom: 25px;
    }
    .btn-body {
        margin: 15px -5px;
        position: relative;
        display: flex;
    }
    .thumbs {
        position: relative;
    }
    .btn-body .btn-login {
        margin: 0 5px;
        width: 100%;
    }
    .btn-body .btn-login a {
        text-decoration: none;
        width: 100%;
        padding: 10px 5px;
        color: #fff;
        background: ;
        border-radius: 5px;
        display: inline-block;
        text-align: center;
        text-shadow: 0 1px 3px rgb(0 0 0 / 0%);
        animation: blinking 1s infinite;
    }
    .btn-body .btn-daftar {
        margin: 0 5px;
        width: 100%;
    }
    .btn-body .btn-daftar a {
        text-decoration: none;
        width: 100%;
        padding: 10px 5px;
        color: #fff;
        background: linear-gradient(#e1c303, #c7a101 8%, #9b7105 22%, #453212 47%, #453212 52%, #9b7105 78%, #c7a101 92%, #e1c303);
        border-radius: 5px;
        display: inline-block;
        text-align: center;
        text-shadow: 0 1px 3px rgb(0 0 0 / 0%);
    }
    .btn-body .btn-items {
        margin: 0 5px;
        width: 100%;
    }
    .btn-body .btn-items a {
        text-decoration: none;
        width: 100%;
        padding: 10px 5px;
        color: #fff;
        background: linear-gradient(#e1c303, #c7a101 8%, #9b7105 22%, #453212 47%, #453212 52%, #9b7105 78%, #c7a101 92%, #e1c303);
        border-radius: 5px;
        display: inline-block;
        text-align: center;
    }
    .box-games-wrapper {
        display: flex;
        flex-direction: row;
        flex-wrap: wrap;
        margin: -5px;
    }
    .box-games-wrapper .box-games {
        width: 20%;
        padding: 5px;
    }
    .box-games-wrapper .box-games .games-img {
        position: relative;
        overflow: hidden;
    }
    .box-games-wrapper .box-games .games-name {
        background-color: #222;
        padding: 5px 3px;
        text-align: center;
        font-weight: 500;
        border-radius: 5px;
        font-size: 12px;
    }
    .games-name h3 {
        font-size: 15px;
        margin: 0;
    }
    .games-name p {
        font-size: 14px;
    }
    .box-games .rtp-box {
        position: relative;
        display: inline-block;
        border-radius: 5px;
        width: 100%;
        margin: 5px 0;
        background-color: #222;
    }
    .color-success {
        background-color: #28a745;
    }
    .color-primary {
        background-color: #0277fa;
    }
    .color-warning {
        background-color: #fed804;
    }
    .color-danger {
        background-color: #dc3545;
    }
    .box-text {
        padding: 5px;
    }
    .box-text a {
        text-decoration: none;
    }
    .box-text table {
        width: 100%;
        text-align: center;
        border-collapse: separate;
        border: 1px solid #fff;
    }
    .box-text table th,
    td {
        border: 1px solid #fff;
        padding: 5px;
    }
    .mt-50 {
        margin-top: 50px;
    }
    footer {
        padding: 15px 5px;
        margin-bottom: 40px;
    }
    footer .footer-text {
        text-align: center;
    }
    .breadcrump-list {
        text-align: center;
        color: #fff;
    }
    .breadcrump-list ul {
        padding: 10px 16px;
        list-style: none;
    }
    .breadcrump-list ul li {
        display: inline;
        font-size: 18px;
    }
    .breadcrump-list ul li + li:before {
        padding: 8px;
        color: #fff;
        content: "\003e";
    }
    .breadcrump-list ul li a {
        color: #ffd386;
        text-decoration: none;
    }
    .mt-10 {
        margin-top: 50px;
    }
    article header {
        background-color: transparent;
        box-shadow: none;
    }
    .content-group table {
        width: 100%;
        border-collapse: collapse;
        text-align: center;
        font-weight: 700;
    }
    .content-group table th,
    .content-group table td {
        padding: 8px;
        border: 1px solid #fee05e;
    }
    .content-group table th {
        color: #fee05e;
        background: #fee05e linear-gradient(180deg, #fee05e, #fee05e);
        text-shadow: 0 1px 3px rgb(0 0 0 / 0%);
    }
    .content-group table td:first-child {
        width: 50%;
    }
    .center-bank {
            text-align: center;
            color: #fff;
            font-weight: bold;
            margin-left: -5px;
        }
            .bank {
            display: inline-block;
            background-color: #fff;
            padding: 3px 10px 5px 10px;
            width: 45%;
            margin: 5px 0 0 0;
            text-align: left;
            border-radius: 6px;
        }

        .bank {
            border-radius: 10px;
            padding: 0px;
            height: 32px;
            width: 45%;
            margin-left: 7px;
            border: groove 3px;
            display: inline-block;
            vertical-align: middle;
        }

        .bank img:first-child {
            width: 65px;
            display: inline-block;
            vertical-align: middle;
            margin-left: auto;
            margin-right: 2px;
            margin-top: 6px;
            margin-bottom: auto;
        }

        .bank img:last-child {
            width: 70px;
            display: inline-block;
            vertical-align: middle;
            margin-left: auto;
            margin-right: auto;
            margin-top: 4px;
        }
    article a,
    footer a {
        text-decoration: none;
    }
    article table {
        width: 100%;
        text-align: center;
    }
    article table th {
        border: 1px solid #fff;
    }
    @media only screen and (max-width: 720px) {
        .box-games-wrapper {
            justify-content: center;
        }
        .box-games-wrapper .box-games {
            width: 33%;
        }
        .box-games .rtp-box .txt {
            font-size: 12px;
        }
        .games-name p {
            font-size: 12px;
        }
        .content table td:first-child {
            width: 30%;
        }
        .content-group table td:first-child {
            width: 60%;
        }
    }
    .btncil {
        background: #0e0d12;
        display: inline-block;
        padding: 5px 25px;
        touch-action: manipulation;
        cursor: pointer;
        text-align: center;
        user-select: none;
        border: 1px solid #000;
        border-radius: 5px;
        font: 600 15px Arial;
        color: #fff;
        letter-spacing: 1.5px;
        transition: all 0.4s;
        animation: blinking 1s infinite;
    }
    @keyframes blinking {
        0% {
            border: 2px solid #eb9704;
        }
        100% {
            border: 2px solid #fff;
        }
    }
    .caption {
        border: solid 1px #c7a101;
        padding: 8px;
        color: #fff;
        background: linear-gradient(#e1c303, #c7a101 8%, #9b7105 22%, #453212 47%, #453212 52%, #9b7105 78%, #c7a101 92%, #e1c303);
        text-shadow: 0 1px 3px rgb(0 0 0 / 0%);
    }
    .footer {
            font-size: 10px;
      		height: 20px;
            color: #fff;
        }
    .dropdown-description {
        background: #1a1819;
        color: #fff;
        padding: 10px;
        border-radius: 5px;
    }
    .dropdown-content {
        padding: 10px;
    }
    .dropdown-header {
        cursor: pointer;
        position: relative;
        padding: 10px;
        background: #1a1819;
        color: #fff;
        border-radius: 5px;
        margin-bottom: 5px;
    }
    .dropdown-header:after {
        content: "▼";
        color: #c99d09;
        display: block;
        text-align: center;
        margin-top: 10px;
    }
    .breadcrumbs {
		color:#fff;
		text-align:center
	}
</style>
</head>
<body>
  <header>
    <div class="header-wrapper">
      <div class="logo">
        <a href="#">
          <amp-img src="https://games-gacor.web.app/img/banner420.png" width="250" height="70" alt="<?php echo $BRANDS ?> Logo" layout="fixed"></amp-img>
        </a>
      </div>
    </div>
  </header>
  <section>
    <div class="dompleng">
      <div class="content">
        <div class="thumbs">
          <amp-carousel width="1000" height="1000" layout="responsive" type="slides" role="region" aria-label="type='slides' carousel">
            <amp-img src="https://sayurmalang.com/img/slotgacor.jpg" width="1080" height="1080" layout="responsive" alt="another sample image"></amp-img>
          </amp-carousel>
        </div>
        <br>
        <div class="btn-body">
          <div class="btn-login">
            <a href="https://games-gacor.web.app/link/strike/" rel="nofollow noreferrer" target="_blank"><strong>DAFTAR</strong></a>
          </div>
          <div class="btn-login">
            <a href="https://games-gacor.web.app/link/strike/" rel="nofollow noreferrer" target="_blank"><strong>MASUK</strong></a>
          </div>
        </div>
        <section class="content-group">
          <table class="dompleng">
            <caption class="caption">
              LINK DAFTAR
            </caption>
            <tr>
              <td style="text-align:left">DAFTAR AKUNPRO</td>
              <td>
                <a href="https://games-gacor.web.app/link/strike/" target="_blank" rel="nofollow noreferrer">
                  <button type="login" class="btncil">DAFTAR</button>
                </a>
              </td>
            </tr>
            <tr>
              <td style="text-align:left">DAFTAR SITUS THAILAND</td>
              <td>
                <a href="https://games-gacor.web.app/link/strike/" target="_blank" rel="nofollow noreferrer">
                  <button type="login" class="btncil">DAFTAR</button>
                </a>
              </td>
            </tr>
          </table>
          <h3 class="caption" style="text-align:center">DAFAR BANK AKTIF</h3>
          <div class="center-bank">
            <div style="margin-left: 5px;" class="bank">
              <img src="https://imgku.io/download/p3yz6GsS.gif" alt="Online" />
              <img src="https://imgku.io/download/oflpF6yT.gif" alt="BCA" />
            </div>
            <div style="margin-left: 5px;" class="bank">
              <img src="https://imgku.io/download/p3yz6GsS.gif" alt="Online" />
              <img src="https://imgku.io/download/iA4CqcGO.webp " alt="Mandiri" />
            </div>
            <div style="margin-left: 5px;" class="bank">
              <img src="https://imgku.io/download/p3yz6GsS.gif" alt="Online" />
              <img src="https://imgku.io/download/2jwvo9Zh.webp" alt="BRI" />
            </div>
            <div style="margin-left: 5px;" class="bank">
              <img src="https://imgku.io/download/p3yz6GsS.gif" alt="Online" />
              <img src="https://imgku.io/download/kLsjJfzl.gif " alt="BNI" />
            </div>
            <div style="margin-left: 5px;" class="bank">
              <img src="https://imgku.io/download/p3yz6GsS.gif" alt="Online" />
              <img src="https://imgku.io/download/0qrcKmfO.gif" alt="Danamon" />
            </div>
            <div style="margin-left: 5px;" class="bank">
              <img src="https://imgku.io/download/p3yz6GsS.gif" alt="Online" />
              <img src="https://imgku.io/download/pV5O8EN9.gif " alt="CIMB" />
            </div>
            <div style="margin-left: 5px;" class="bank">
              <img src="https://imgku.io/download/p3yz6GsS.gif" alt="Online" />
              <img src="https://imgku.io/download/OWegqDow.gif" alt="Permata" />
            </div>
            <div style="margin-left: 5px;" class="bank">
              <img src="https://imgku.io/download/p3yz6GsS.gif" alt="Online" />
              <img src="https://imgku.io/download/lp5gBdXQ.gif" alt="OVO" />
            </div>
            <div style="margin-left: 5px;" class="bank">
              <img src="https://imgku.io/download/p3yz6GsS.gif" alt="Online" />
              <img src="https://imgku.io/download/C6qsimIg.gif" alt="Gopay" />
            </div>
            <div style="margin-left: 5px;" class="bank">
              <img src="https://imgku.io/download/p3yz6GsS.gif" alt="Online" />
              <img src="https://imgku.io/download/E1d2TOR3.gif" alt="Dana" />
            </div>
            <div style="margin-left: 5px;" class="bank">
              <img src="https://imgku.io/download/p3yz6GsS.gif" alt="Online" />
              <img src="https://imgku.io/download/IP4MFef9.gif" alt="LinkAja" />
            </div>
            <div style='margin-left: 5px;' class='bank'>
              <img src='https://imgku.io/download/p3yz6GsS.gif' alt="Online">
              <img src='https://imgku.io/download/76xrFlfA.gif' alt="Qris">
            </div>
            <main>
              <h1 class="description" style="text-align:center;"><?php echo $BRANDS; ?>: Link Alternatif Situs <?php echo $BRANDS; ?> Gacor Terpercaya Server Thailand</h1>
              <span>
                <p style="text-align:center"><?php echo $BRANDS ?> adalah pilihan ideal bagi pencinta slot online yang mencari bocoran RTP live slot gacor dengan peluang maxwin besar hari ini.</p>
              </span><br>
              <footer>
                <div class="container">
                  <div class="footer">&copy; Copyright 2024 <a href="https://pembayaran.polhas.ac.id/pendidikan/?bgt=<?php echo $BRANDS ?>"><?php echo $BRANDS ?></a>&nbsp;All Right Reserved BY SEO-420</div>
                </div>
              </footer>
            </main>
            <div class="nav">
              <div class="menu">
                <a href="https://games-gacor.web.app/link/strike/" rel="nofollow noopener">
                  <amp-img layout="intrinsic" height="100" width="100" src="https://games-gacor.web.app/img/faviconcat.png" alt="bonus"></amp-img>
                  HOME
                </a>
                <a href="https://games-gacor.web.app/link/strike/" rel="nofollow noopener" class="tada" target="_blank">
                  <amp-img class="center" layout="intrinsic" height="120" width="120" src="https://games-gacor.web.app/img/faviconcat.png" alt="login"></amp-img>
                  DAFTAR
                </a>
                <a href="https://games-gacor.web.app/link/strike/" rel="nofollow noopener" target="_blank">
                  <amp-img layout="intrinsic" height="100" width="100" src="https://games-gacor.web.app/img/faviconcat.png" alt="live chat"></amp-img>
                  LIVECHAT
                </a>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  </section>
</body>
</html>